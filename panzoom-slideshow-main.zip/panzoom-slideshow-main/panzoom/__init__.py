"""
PanZoom Slideshow - Professional Ken Burns Video Generator
"""

__version__ = "1.1.0"
__author__ = "Carnaverone Studio"
